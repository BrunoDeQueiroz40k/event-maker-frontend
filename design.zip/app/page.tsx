"use client"

import { useState } from "react"
import { Calendar } from "@/components/calendar"
import { EventForm } from "@/components/event-form"
import { Header } from "@/components/header"

export default function Page() {
  const [selectedDate, setSelectedDate] = useState<Date | null>(null)
  const [showEventForm, setShowEventForm] = useState(false)

  const handleDateClick = (date: Date) => {
    setSelectedDate(date)
    setShowEventForm(true)
  }

  const handleCloseForm = () => {
    setShowEventForm(false)
    setSelectedDate(null)
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-primary mb-2 tracking-wider uppercase font-mono">
            {"WARHAMMER 40K EVENT PROTOCOL"}
          </h1>
          <p className="text-muted-foreground font-mono text-sm tracking-wide">
            {"VRCHAT BATTLE COORDINATION SYSTEM // IMPERIUM SANCTIONED"}
          </p>
        </div>

        {!showEventForm ? (
          <Calendar onDateClick={handleDateClick} />
        ) : (
          <EventForm selectedDate={selectedDate} onClose={handleCloseForm} />
        )}
      </main>
    </div>
  )
}
