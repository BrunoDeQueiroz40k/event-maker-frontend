"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { X, Plus, Trash2 } from "lucide-react"

interface EventFormProps {
  selectedDate: Date | null
  onClose: () => void
}

const LEGIONS = [
  "Ultramarines",
  "Blood Angels",
  "Dark Angels",
  "Space Wolves",
  "Imperial Fists",
  "Salamanders",
  "Raven Guard",
  "Iron Hands",
  "White Scars",
  "Black Templars",
  "Chaos Space Marines",
  "Death Guard",
  "Thousand Sons",
  "World Eaters",
  "Emperor's Children",
  "Orks",
  "Tyranids",
  "Necrons",
  "Tau Empire",
  "Eldar",
  "Dark Eldar",
]

const AVATAR_CLASSES = [
  "Tactical Marine",
  "Assault Marine",
  "Devastator",
  "Terminator",
  "Scout",
  "Dreadnought",
  "Chaplain",
  "Librarian",
  "Apothecary",
  "Techmarine",
]

interface Avatar {
  id: string
  link: string
  class: string
}

export function EventForm({ selectedDate, onClose }: EventFormProps) {
  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [selectedLegions, setSelectedLegions] = useState<string[]>([])
  const [customLegion, setCustomLegion] = useState("")
  const [showCustomLegion, setShowCustomLegion] = useState(false)
  const [matchupLegion1, setMatchupLegion1] = useState("")
  const [matchupLegion2, setMatchupLegion2] = useState("")
  const [map, setMap] = useState("")
  const [organizer, setOrganizer] = useState("")
  const [supervisor, setSupervisor] = useState("")
  const [avatars, setAvatars] = useState<Avatar[]>([{ id: "1", link: "", class: "" }])

  const toggleLegion = (legion: string) => {
    setSelectedLegions((prev) => (prev.includes(legion) ? prev.filter((l) => l !== legion) : [...prev, legion]))
  }

  const toggleCustomLegion = () => {
    setShowCustomLegion((prev) => !prev)
    if (showCustomLegion) {
      setCustomLegion("")
    }
  }

  const addAvatar = () => {
    setAvatars((prev) => [...prev, { id: Date.now().toString(), link: "", class: "" }])
  }

  const removeAvatar = (id: string) => {
    setAvatars((prev) => prev.filter((avatar) => avatar.id !== id))
  }

  const updateAvatarLink = (id: string, link: string) => {
    setAvatars((prev) => prev.map((avatar) => (avatar.id === id ? { ...avatar, link } : avatar)))
  }

  const updateAvatarClass = (id: string, avatarClass: string) => {
    setAvatars((prev) => prev.map((avatar) => (avatar.id === id ? { ...avatar, class: avatarClass } : avatar)))
  }

  const formattedDate = selectedDate
    ? selectedDate.toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric",
      })
    : ""

  const allLegions = [...selectedLegions, ...(customLegion ? [customLegion] : [])]

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Form Section */}
      <div className="imperial-border bg-card p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-primary font-mono tracking-wider uppercase">
              {"EVENT CREATION PROTOCOL"}
            </h2>
            <p className="text-sm text-muted-foreground font-mono mt-1">
              {"DATE: "}
              {formattedDate.toUpperCase()}
            </p>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="hover:bg-destructive/20 hover:text-destructive"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        <form className="space-y-6">
          {/* Basic Information */}
          <div className="space-y-4 p-4 bg-muted/20 border border-border">
            <h3 className="text-sm font-bold text-primary font-mono tracking-wider uppercase border-b border-primary/30 pb-2">
              {"// BASIC INFORMATION"}
            </h3>

            <div className="space-y-2">
              <Label htmlFor="title" className="text-xs font-mono text-foreground uppercase tracking-wide">
                {"Event Title"}
              </Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter event designation..."
                className="bg-background border-border font-mono"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description" className="text-xs font-mono text-foreground uppercase tracking-wide">
                {"Event Description"}
              </Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Enter tactical briefing..."
                className="bg-background border-border font-mono min-h-[100px]"
              />
            </div>
          </div>

          {/* Legion Selection */}
          <div className="space-y-4 p-4 bg-muted/20 border border-border">
            <h3 className="text-sm font-bold text-primary font-mono tracking-wider uppercase border-b border-primary/30 pb-2">
              {"// PARTICIPATING LEGIONS"}
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {LEGIONS.map((legion) => (
                <div key={legion} className="flex items-center space-x-2">
                  <Checkbox
                    id={legion}
                    checked={selectedLegions.includes(legion)}
                    onCheckedChange={() => toggleLegion(legion)}
                    className="border-primary/50 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                  />
                  <Label
                    htmlFor={legion}
                    className="text-xs font-mono text-foreground cursor-pointer hover:text-primary transition-colors"
                  >
                    {legion}
                  </Label>
                </div>
              ))}
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="custom-legion"
                  checked={showCustomLegion}
                  onCheckedChange={toggleCustomLegion}
                  className="border-primary/50 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                />
                <Label
                  htmlFor="custom-legion"
                  className="text-xs font-mono text-foreground cursor-pointer hover:text-primary transition-colors"
                >
                  Outro
                </Label>
              </div>
            </div>
            {showCustomLegion && (
              <div className="mt-3">
                <Input
                  value={customLegion}
                  onChange={(e) => setCustomLegion(e.target.value)}
                  placeholder="Digite o nome da legião..."
                  className="bg-background border-border font-mono text-sm"
                />
              </div>
            )}
          </div>

          {/* Battle Configuration */}
          <div className="space-y-4 p-4 bg-muted/20 border border-border">
            <h3 className="text-sm font-bold text-primary font-mono tracking-wider uppercase border-b border-primary/30 pb-2">
              {"// BATTLE CONFIGURATION"}
            </h3>

            <div className="space-y-2">
              <Label className="text-xs font-mono text-foreground uppercase tracking-wide">{"Legion Matchup"}</Label>
              <div className="flex items-center gap-2">
                <select
                  value={matchupLegion1}
                  onChange={(e) => setMatchupLegion1(e.target.value)}
                  className="flex-1 h-9 rounded-md border border-border bg-background px-3 py-1 text-sm font-mono text-foreground"
                  disabled={allLegions.length === 0}
                >
                  <option value="">Selecione...</option>
                  {allLegions.map((legion) => (
                    <option key={legion} value={legion}>
                      {legion}
                    </option>
                  ))}
                </select>
                <span className="text-primary font-mono">VS</span>
                <select
                  value={matchupLegion2}
                  onChange={(e) => setMatchupLegion2(e.target.value)}
                  className="flex-1 h-9 rounded-md border border-border bg-background px-3 py-1 text-sm font-mono text-foreground"
                  disabled={allLegions.length === 0}
                >
                  <option value="">Selecione...</option>
                  {allLegions.map((legion) => (
                    <option key={legion} value={legion}>
                      {legion}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="map" className="text-xs font-mono text-foreground uppercase tracking-wide">
                {"Battle Map / Location"}
              </Label>
              <Input
                id="map"
                value={map}
                onChange={(e) => setMap(e.target.value)}
                placeholder="Enter VRChat world name..."
                className="bg-background border-border font-mono"
              />
            </div>
          </div>

          {/* Personnel */}
          <div className="space-y-4 p-4 bg-muted/20 border border-border">
            <h3 className="text-sm font-bold text-primary font-mono tracking-wider uppercase border-b border-primary/30 pb-2">
              {"// PERSONNEL ASSIGNMENT"}
            </h3>

            <div className="space-y-2">
              <Label htmlFor="organizer" className="text-xs font-mono text-foreground uppercase tracking-wide">
                {"Event Organizer"}
              </Label>
              <Input
                id="organizer"
                value={organizer}
                onChange={(e) => setOrganizer(e.target.value)}
                placeholder="Enter organizer name..."
                className="bg-background border-border font-mono"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="supervisor" className="text-xs font-mono text-muted-foreground uppercase tracking-wide">
                {"Supervisor (Optional)"}
              </Label>
              <Input
                id="supervisor"
                value={supervisor}
                onChange={(e) => setSupervisor(e.target.value)}
                placeholder="Enter supervisor name..."
                className="bg-background border-border font-mono"
              />
            </div>
          </div>

          <div className="space-y-4 p-4 bg-muted/20 border border-border">
            <div className="flex items-center justify-between border-b border-primary/30 pb-2">
              <h3 className="text-sm font-bold text-primary font-mono tracking-wider uppercase">
                {"// AVATAR CONFIGURATION"}
              </h3>
              <Button
                type="button"
                size="sm"
                onClick={addAvatar}
                className="bg-primary/20 hover:bg-primary/30 text-primary border border-primary/50 h-7 px-2"
              >
                <Plus className="h-3 w-3 mr-1" />
                Adicionar
              </Button>
            </div>

            <div className="space-y-3">
              {avatars.map((avatar, index) => (
                <div key={avatar.id} className="p-3 bg-background border border-border space-y-2">
                  <div className="flex items-center justify-between mb-2">
                    <Label className="text-xs font-mono text-muted-foreground uppercase">Avatar {index + 1}</Label>
                    {avatars.length > 1 && (
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        onClick={() => removeAvatar(avatar.id)}
                        className="h-6 w-6 p-0 hover:bg-destructive/20 hover:text-destructive"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`avatar-link-${avatar.id}`} className="text-xs font-mono text-foreground">
                      Link do Avatar
                    </Label>
                    <Input
                      id={`avatar-link-${avatar.id}`}
                      value={avatar.link}
                      onChange={(e) => updateAvatarLink(avatar.id, e.target.value)}
                      placeholder="Cole o link do avatar..."
                      className="bg-muted border-border font-mono text-sm"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`avatar-class-${avatar.id}`} className="text-xs font-mono text-foreground">
                      Classe
                    </Label>
                    <select
                      id={`avatar-class-${avatar.id}`}
                      value={avatar.class}
                      onChange={(e) => updateAvatarClass(avatar.id, e.target.value)}
                      className="w-full h-9 rounded-md border border-border bg-muted px-3 py-1 text-sm font-mono text-foreground"
                    >
                      <option value="">Selecione uma classe...</option>
                      {AVATAR_CLASSES.map((avatarClass) => (
                        <option key={avatarClass} value={avatarClass}>
                          {avatarClass}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 pt-4">
            <Button
              type="submit"
              className="flex-1 bg-primary hover:bg-primary/80 text-primary-foreground font-mono tracking-wider uppercase"
            >
              {">> INITIATE EVENT <<"}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1 border-destructive/50 text-destructive hover:bg-destructive/20 hover:border-destructive font-mono tracking-wider uppercase bg-transparent"
            >
              {"ABORT"}
            </Button>
          </div>
        </form>
      </div>

      <div className="imperial-border bg-card p-6">
        <h2 className="text-2xl font-bold text-primary font-mono tracking-wider uppercase mb-6">{"EVENT PREVIEW"}</h2>

        <div className="space-y-4">
          {/* Date */}
          <div className="p-3 bg-muted/20 border border-border">
            <p className="text-xs font-mono text-muted-foreground uppercase mb-1">Data</p>
            <p className="text-sm font-mono text-foreground">{formattedDate || "Não definida"}</p>
          </div>

          {/* Title */}
          <div className="p-3 bg-muted/20 border border-border">
            <p className="text-xs font-mono text-muted-foreground uppercase mb-1">Título</p>
            <p className="text-sm font-mono text-foreground">{title || "Sem título"}</p>
          </div>

          {/* Description */}
          <div className="p-3 bg-muted/20 border border-border">
            <p className="text-xs font-mono text-muted-foreground uppercase mb-1">Descrição</p>
            <p className="text-sm font-mono text-foreground whitespace-pre-wrap">{description || "Sem descrição"}</p>
          </div>

          {/* Legions */}
          <div className="p-3 bg-muted/20 border border-border">
            <p className="text-xs font-mono text-muted-foreground uppercase mb-1">Legiões Participantes</p>
            {allLegions.length > 0 ? (
              <div className="flex flex-wrap gap-2 mt-2">
                {allLegions.map((legion) => (
                  <span
                    key={legion}
                    className="px-2 py-1 bg-primary/20 border border-primary/50 text-xs font-mono text-primary"
                  >
                    {legion}
                  </span>
                ))}
              </div>
            ) : (
              <p className="text-sm font-mono text-foreground">Nenhuma legião selecionada</p>
            )}
          </div>

          {/* Matchup */}
          <div className="p-3 bg-muted/20 border border-border">
            <p className="text-xs font-mono text-muted-foreground uppercase mb-1">Confronto</p>
            <p className="text-sm font-mono text-foreground">
              {matchupLegion1 && matchupLegion2 ? `${matchupLegion1} VS ${matchupLegion2}` : "Não definido"}
            </p>
          </div>

          {/* Map */}
          <div className="p-3 bg-muted/20 border border-border">
            <p className="text-xs font-mono text-muted-foreground uppercase mb-1">Mapa</p>
            <p className="text-sm font-mono text-foreground">{map || "Não definido"}</p>
          </div>

          {/* Organizer */}
          <div className="p-3 bg-muted/20 border border-border">
            <p className="text-xs font-mono text-muted-foreground uppercase mb-1">Organizador</p>
            <p className="text-sm font-mono text-foreground">{organizer || "Não definido"}</p>
          </div>

          {/* Supervisor */}
          {supervisor && (
            <div className="p-3 bg-muted/20 border border-border">
              <p className="text-xs font-mono text-muted-foreground uppercase mb-1">Supervisor</p>
              <p className="text-sm font-mono text-foreground">{supervisor}</p>
            </div>
          )}

          {/* Avatars with Classes */}
          <div className="p-3 bg-muted/20 border border-border">
            <p className="text-xs font-mono text-muted-foreground uppercase mb-1">Avatares e Classes</p>
            {avatars.some((a) => a.link || a.class) ? (
              <div className="space-y-2 mt-2">
                {avatars.map((avatar, index) => {
                  if (!avatar.link && !avatar.class) return null
                  return (
                    <div key={avatar.id} className="p-2 bg-background border border-border/50">
                      <p className="text-xs font-mono text-primary mb-1">Avatar {index + 1}</p>
                      {avatar.link && (
                        <p className="text-xs font-mono text-foreground break-all mb-1">
                          <span className="text-muted-foreground">Link:</span> {avatar.link}
                        </p>
                      )}
                      {avatar.class && (
                        <p className="text-xs font-mono text-foreground">
                          <span className="text-muted-foreground">Classe:</span>{" "}
                          <span className="text-primary">{avatar.class}</span>
                        </p>
                      )}
                    </div>
                  )
                })}
              </div>
            ) : (
              <p className="text-sm font-mono text-foreground">Nenhum avatar configurado</p>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
